const gameBoard = document.getElementById("gameBoard");
const restartBtn = document.getElementById("restartBtn");
const nextLevelBtn = document.getElementById("nextLevelBtn");

const levelNumEl = document.getElementById("levelNum");
const pointsEl = document.getElementById("points");
const movesEl = document.getElementById("moves");
const timeEl = document.getElementById("time");

const winScreen = document.getElementById("winScreen");
const winPointsEl = document.getElementById("winPoints");
const starsEl = document.getElementById("stars");

/* =======================
   EMOJI WORLDS (THEMES)
======================= */
const emojiSets = {
  animals: ["🐶","🐱","🐼","🐯","🦁","🦊","🐸","🐵","🐨","🐮","🐷","🐔"],
  fruits: ["🍎","🍌","🍇","🍉","🍓","🍍","🥝","🍒","🍑","🍊","🍋","🥭"],
  food: ["🍔","🍟","🍕","🌭","🍿","🍩","🍪","🎂","🍫","🍦","🍰","🥪"],
  gems: ["💎","👑","🏆","⭐","🌟","✨","🔥","⚡","💥","🪙","🔮","🎁"],
  vehicles: ["🚗","🚕","🚙","🚌","🚓","🚑","🚒","🏎️","🚜","🚲","🛵","✈️"],
  sports: ["⚽","🏀","🏈","⚾","🎾","🏐","🏸","🥊","🏓","⛳","🎯","🥅"],
  games: ["🎮","🕹️","👾","🤖","🎲","🎯","🚀","🛸","⚙️","🔋","💻","📱"],
  places: ["🏖️","🏝️","🏜️","🏕️","🏔️","🌋","🏟️","🏯","🏰","🗽","🗼","🎡"],
  space: ["🌍","🌙","⭐","🌟","☄️","🪐","🚀","🛰️","👽","🌌","🌠","🔭"],
  faces: ["😀","😎","🤩","🥳","😍","😜","🤠","😂","😇","🤓","😱","🥶"]
};

/* =======================
   GAME STATE
======================= */
let firstCard = null;
let secondCard = null;
let lockBoard = false;
let moves = 0;
let matchedPairs = 0;

let timer = 0;
let timerInterval = null;

let currentLevel = Number(localStorage.getItem("level")) || 1;
let totalPoints = Number(localStorage.getItem("points")) || 0;

levelNumEl.textContent = currentLevel;
pointsEl.textContent = totalPoints;

/* =======================
   UTILITIES
======================= */
function shuffle(arr) {
  return arr.sort(() => 0.5 - Math.random());
}

/* =======================
   LEVEL DIFFICULTY
======================= */
function getLevelConfig(level) {
  if (level <= 10)  return { pairs: 6, cols: 3, reward: 10 };
  if (level <= 30)  return { pairs: 8, cols: 4, reward: 15 };
  if (level <= 60)  return { pairs: 10, cols: 5, reward: 20 };
  return               { pairs: 12, cols: 6, reward: 30 };
}

/* =======================
   THEME BY LEVEL (WORLDS)
======================= */
function getEmojiSetByLevel(level) {
  if (level <= 10)  return emojiSets.animals;
  if (level <= 20)  return emojiSets.fruits;
  if (level <= 30)  return emojiSets.food;
  if (level <= 40)  return emojiSets.gems;
  if (level <= 50)  return emojiSets.vehicles;
  if (level <= 60)  return emojiSets.sports;
  if (level <= 70)  return emojiSets.games;
  if (level <= 80)  return emojiSets.places;
  if (level <= 90)  return emojiSets.space;
  return               emojiSets.faces; // 91–100
}

/* =======================
   TIMER
======================= */
function startTimer() {
  clearInterval(timerInterval);
  timer = 0;
  timeEl.textContent = timer;

  timerInterval = setInterval(() => {
    timer++;
    timeEl.textContent = timer;
  }, 1000);
}

function stopTimer() {
  clearInterval(timerInterval);
}

/* =======================
   BOARD SETUP
======================= */
function createBoard() {
  resetTurn();
  gameBoard.innerHTML = "";
  moves = 0;
  matchedPairs = 0;
  movesEl.textContent = moves;
  winScreen.style.display = "none";

  startTimer();

  const { pairs, cols } = getLevelConfig(currentLevel);
  gameBoard.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;

  const emojiPool = getEmojiSetByLevel(currentLevel);
  let selected = emojiPool.slice(0, pairs);
  let cards = shuffle([...selected, ...selected]);

  cards.forEach(emoji => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-inner">
        <div class="card-front">❓</div>
        <div class="card-back">${emoji}</div>
      </div>
    `;
    card.addEventListener("click", () => flipCard(card, emoji));
    gameBoard.appendChild(card);
  });
}

/* =======================
   GAMEPLAY
======================= */
function flipCard(card, emoji) {
  if (lockBoard || card === firstCard || card.classList.contains("flipped")) return;

  card.classList.add("flipped");
  card.dataset.emoji = emoji;

  if (!firstCard) {
    firstCard = card;
    return;
  }

  secondCard = card;
  moves++;
  movesEl.textContent = moves;

  checkMatch();
}

function checkMatch() {
  const isMatch = firstCard.dataset.emoji === secondCard.dataset.emoji;

  if (isMatch) {
    matchedPairs++;
    resetTurn();
    checkWin();
  } else {
    lockBoard = true;
    setTimeout(() => {
      firstCard.classList.remove("flipped");
      secondCard.classList.remove("flipped");
      resetTurn();
    }, 800);
  }
}

/* =======================
   STARS + WIN LOGIC
======================= */
function calculateStars() {
  if (moves <= 12) return 3;
  if (moves <= 18) return 2;
  return 1;
}

function checkWin() {
  const { pairs, reward } = getLevelConfig(currentLevel);

  if (matchedPairs === pairs) {
    stopTimer();

    const stars = calculateStars();
    const bonus = stars * 5;
    const earned = reward + bonus;

    totalPoints += earned;
    currentLevel = Math.min(100, currentLevel + 1);

    localStorage.setItem("points", totalPoints);
    localStorage.setItem("level", currentLevel);

    pointsEl.textContent = totalPoints;
    levelNumEl.textContent = currentLevel;
    winPointsEl.textContent = earned;

    starsEl.innerHTML = "⭐".repeat(stars);

    winScreen.style.display = "flex";
  }
}

/* =======================
   RESET
======================= */
function resetTurn() {
  firstCard = null;
  secondCard = null;
  lockBoard = false;
}

/* =======================
   BUTTONS
======================= */
restartBtn.addEventListener("click", createBoard);
nextLevelBtn.addEventListener("click", createBoard);

/* =======================
   START GAME
======================= */
createBoard();
